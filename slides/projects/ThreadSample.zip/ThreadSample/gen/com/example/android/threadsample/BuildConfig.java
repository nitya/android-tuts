/** Automatically generated file. DO NOT MODIFY */
package com.example.android.threadsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}